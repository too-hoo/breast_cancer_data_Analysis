# SVM:如何进行乳腺癌检测？

## 如何在sklearn中使用SVM

## 如何用SVM进行乳腺癌检测

## 总结